Place files that are in the libraries folder into your local Arduino libraries folder.
Feel free to contact me via my blog if you require assistance in making this project work

http://carrierfrequency.blogspot.com/2011/08/si4735-amfmswlw-radio-project.html

Thanks,
Jon
