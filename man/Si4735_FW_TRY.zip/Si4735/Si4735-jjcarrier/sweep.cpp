void sweep(){
  radio.mute();
  Metrics RSQ;
   Serial.print("SCAN_BEGIN:");
  for(word i=6400;i<=10800;i+=10){
     Serial.print(i,DEC);
     Serial.print(":");
     radio.tuneFrequency(i); 
     radio.getRSQ(&RSQ);
     Serial.print(RSQ.SNR,DEC);
     Serial.print(",");
  }  
  Serial.print(".");
  radio.unmute();
  //radio.tuneFrequency(frequency);
}