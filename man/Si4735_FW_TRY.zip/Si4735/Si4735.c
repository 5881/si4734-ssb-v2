#include <stdlib.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include "Si4735.h"
#include "Si4735_path.h"
#include "../i2c/i2cmaster.h"
        volatile uint8_t _mode, _response[16];
        uint8_t _haverds, _interrupt, _seeking;
        volatile uint8_t _status = 0x00;


uint16_t word(uint8_t hi8, uint8_t lo8)
{
	return hi8 << 8 | lo8;
}

uint8_t highByte(uint16_t wordval)
{
	return wordval >> 8;
}

uint8_t lowByte(uint16_t wordval)
{
	return wordval;
}

uint8_t constrain(uint8_t chval, uint8_t lowlevel, uint8_t highlevel)
{
	uint8_t temp = 0;
	if ((chval >= lowlevel) && (chval <= highlevel)) temp = chval;
	if (chval < lowlevel) temp = lowlevel;
	if (chval > highlevel) temp = highlevel;
	
	return temp;
}



void Si4735_updateStatus(void){
 //I2C runs at 100kHz when using the Wire library, 100kHz = 10us period
 //so wait 10 bit-times for something to become available.	
    i2c_start(0xC7);//7
	_delay_us(100);
    _status=i2c_read(0);
	_delay_us(100);	
    i2c_stop();
// 	serial_printLn(" ");
// 	serial_print("## [i2c STATUS = ");
// 	serial_PutHex(_status);
// 	serial_print("] ");
// 	serial_printLn(" ");
}

uint8_t Si4735_getStatus(void){
	Si4735_updateStatus();
	return _status;
}

void Si4735_getResponse(){
//I2C runs at 100kHz when using the Wire library, 100kHz = 10us
//period so wait 10 bit-times for something to become available.

// 	serial_printLn(" ");
// 	serial_print("## [i2c RESPONSE = ");

    i2c_start(0xC7);
	for(int i = 0; i < 16; i++) {
	_delay_us(100);	
	_response[i] = i2c_read(1);
/*	serial_PutHex(_response[i]);*/
	}
	_delay_us(100);	
	i2c_stop();
	
// 	serial_print("] ");
// 	serial_printLn(" ");
}

void Si4735_sendCommandInternal(uint8_t command, uint8_t arg1, uint8_t arg2, uint8_t arg3,
uint8_t arg4, uint8_t arg5, uint8_t arg6, uint8_t arg7){

	i2c_start(0xC6);
	i2c_write(command);
	i2c_write(arg1);
	i2c_write(arg2);
	i2c_write(arg3);
	i2c_write(arg4);
	i2c_write(arg5);
	i2c_write(arg6);
	i2c_write(arg7);
	i2c_stop();
	
	_delay_us(10);
}

void Si4735_waitForInterrupt(uint8_t which){
	while(((Si4735_getStatus() & which) == 1))
	{
		if (which == SI4735_STATUS_STCINT)
		//According to the datasheet, the chip would prefer we don't
		//disturb it with serial communication while it's seeking or
		//tuning into a station. Sleep for two channel seek-times to
		//give it a rest.
		//NOTE: this means seek/tune operations will not complete in
		//less than 120ms, regardless of signal quality. If you don't
		//like this, switch to interrupt mode (like you should have,
		//from the beginning).
		_delay_ms(120);
		
		
		
// 		serial_printLn(" ");
// 		serial_PutHex(_status);
// 		serial_print(" recived, but need ");
// 		serial_PutHex(which);
	}
// 		serial_printLn(" ");
// 		serial_PutHex(_status);
// 		serial_print(" recived, but need ");
// 		serial_PutHex(which);
}

void Si4735_sendCommand(uint8_t command, uint8_t arg1, uint8_t arg2, uint8_t arg3,
uint8_t arg4, uint8_t arg5, uint8_t arg6, uint8_t arg7){
	if (_seeking==1) {
		//The datasheet strongly recommends that no other command (not only a tune
		//or seek one and except GET_INT_STATUS) is sent until the current
		//seek/tune operation is complete.
		//NOTE: the datasheet makes it clear STC implies CTS.
		Si4735_waitForInterrupt(SI4735_STATUS_STCINT);
		_seeking = 0;
	} else Si4735_waitForInterrupt(SI4735_STATUS_CTS);
	Si4735_sendCommandInternal(command, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
}


/*
void Si4735_path_SSB()
{
	uint8_t ARGS;
	ARGS = pgm_read_byte(&Si4735_SSB_FULL[125][3]);
}
*/


void Si4735_setProperty(uint16_t property, uint16_t value){
	Si4735_sendCommand(SI4735_CMD_SET_PROPERTY, 0x00, highByte(property),
	lowByte(property), highByte(value), lowByte(value),0,0);
	//Datasheet states SET_PROPERTY completes 10ms after sending the command
	//irrespective of CTS coming up earlier than that, so we wait anyway.
	_delay_ms(10);
}

void Si4735_HWMute(uint8_t isMute){
	if (isMute)
	{
		PORTD |= _BV(SI4735_PIN_MUTE_HW);
			
	}else
	{
		PORTD &= ~_BV(SI4735_PIN_MUTE_HW);
	}
}


void Si4735_unMute(uint8_t minvol){
	//     if(minvol == 1) setVolume(0);
	     Si4735_setProperty(SI4735_PROP_RX_HARD_MUTE, word(0x00, 0x00));
}

void Si4735_end(uint8_t hardoff){
	Si4735_HWMute(1);
	Si4735_sendCommand(SI4735_CMD_POWER_DOWN,0,0,0,0,0,0,0);
	if(hardoff == 1) {
		//Datasheet calls for 10ns delay; an Arduino running at 20MHz (4MHz
		//faster than the Uno. mind you) has a clock period of 50ns so no action
		//needed.
		_delay_ms(10);
		SI4735_PIN_RESET_LOW;
	}
}

void Si4735_setMode(uint8_t mode){

	Si4735_end(0);
	_mode = mode;
	_seeking = 0;

	switch(_mode){
		case SI4735_MODE_FM:
		Si4735_sendCommand(
		SI4735_CMD_POWER_UP,
		SI4735_FLG_XOSCEN | SI4735_FUNC_FM,
		SI4735_OUT_ANALOG,0,0,0,0,0);
		break;
		case SI4735_MODE_AM:
		case SI4735_MODE_SW:
		case SI4735_MODE_LW:
		Si4735_sendCommand(
		SI4735_CMD_POWER_UP,
		SI4735_FLG_XOSCEN | SI4735_FUNC_AM,
		SI4735_OUT_ANALOG,0,0,0,0,0);
		break;
	}
	
	_delay_ms(650);
	//Configure GPO lines to maximize stability (see datasheet for discussion)
	//No need to do anything for GPO1 if using SPI
	//No need to do anything for GPO2 if using interrupts
	
	Si4735_sendCommand(SI4735_CMD_GPIO_CTL, SI4735_FLG_GPO1OEN | SI4735_FLG_GPO2OEN,0,0,0,0,0,0);
	
	
	if (_mode == SI4735_MODE_FM)
	{
		Si4735_setProperty(SI4735_PROP_DEBUG_CONTROL, 0x0000);
		Si4735_switchAMI(0);
	}


	//Set GPO2 high if using interrupts as Si4735 has a LOW active INT line


	//Enable CTS, end-of-seek and RDS interrupts (if in FM mode)

	//The chip is alive and interrupts have been configured on its side, switch
	//ourselves to interrupt operation if so requested and if wiring was
	//properly done.


	//Disable Mute
	Si4735_unMute(0);

	//Set the seek band for the desired mode (AM and FM can use defaults)
// 	switch(_mode){
// 		case SI4735_MODE_SW:
// 		//Set the lower band limit for Short Wave Radio to 2.3 MHz
// 		Si4735_setProperty(SI4735_PROP_AM_SEEK_BAND_BOTTOM, 0x08FC);
// 		//Set the upper band limit for Short Wave Radio to 23 MHz
// 		Si4735_setProperty(SI4735_PROP_AM_SEEK_BAND_TOP, 0x59D8);
// 		break;
// 		case SI4735_MODE_LW:
// 		//Set the lower band limit for Long Wave Radio to 152 kHz
// 		Si4735_setProperty(SI4735_PROP_AM_SEEK_BAND_BOTTOM, 0x0099);
// 		//Set the upper band limit for Long Wave Radio to 279 kHz
// 		Si4735_setProperty(SI4735_PROP_AM_SEEK_BAND_TOP, 0x0117);
// 		break;
// 	}
	
	Si4735_setDeemphasis(1);
	Si4735_HWMute(0);
}

void Si4735_enableRDS(void){
	//Enable and configure RDS reception
	if(_mode == SI4735_MODE_FM) {
		Si4735_setProperty(SI4735_PROP_FM_RDS_INT_SOURCE, word(0x00,
		SI4735_FLG_RDSRECV));
		//Set the FIFO high-watermark to 12 RDS blocks, which is safe even for
		//old chips, yet large enough to improve performance.
		Si4735_setProperty(SI4735_PROP_FM_RDS_INT_FIFO_COUNT, word(0x00, 0x0C));
		Si4735_setProperty(SI4735_PROP_FM_RDS_CONFIG, word(SI4735_FLG_BLETHA_35 |
		SI4735_FLG_BLETHB_35 | SI4735_FLG_BLETHC_35 |
		SI4735_FLG_BLETHD_35, SI4735_FLG_RDSEN));
	}
}

void Si4735_completeTune(void) {
	//Make sendCommand() below block until the seek/tune operation completes.
	//_seeking = 1;
	//Make future off-to-on STCINT transitions visible (again).
	switch(_mode){
		case SI4735_MODE_FM:
		Si4735_sendCommand(SI4735_CMD_FM_TUNE_STATUS, SI4735_FLG_INTACK,0,0,0,0,0,0);
		break;
		case SI4735_MODE_AM:
		case SI4735_MODE_SW:
		case SI4735_MODE_LW:
		Si4735_sendCommand(SI4735_CMD_AM_TUNE_STATUS, SI4735_FLG_INTACK,0,0,0,0,0,0);
		break;
	}
	if(_mode == SI4735_MODE_FM) Si4735_enableRDS();
}

void Si4735_switchAMI(uint8_t relaymode)
{	// 0 - FM
	// 1 - AM - magnet antenna
	// 2 - AM - Wire antenna
	// 3 - AM - Telescopic antenna

	switch(relaymode)
	{
		case 0: 
		case 1: Si4735_sendCommand(SI4735_CMD_GPIO_SET,0,0,0,0,0,0,0);
		break;
		case 2: Si4735_sendCommand(SI4735_CMD_GPIO_SET,SI4735_FLG_GPO1LEVEL,0,0,0,0,0,0); 
		break;
		case 3: Si4735_sendCommand(SI4735_CMD_GPIO_SET,SI4735_FLG_GPO1LEVEL | SI4735_FLG_GPO2LEVEL,0,0,0,0,0,0); 
		break;
	}
}

void Si4735_HWinit(){
    //Start by resetting the Si4735 and configuring the communication protocol

	DDRD |= _BV(SI4735_PIN_MUTE_HW);         // HW mute
	DDRC |= _BV(SI4735_PIN_RESET_HW);         // reset
	SI4735_PIN_RESET_LOW;
	

	Si4735_HWMute(1);

    //GPO1 is connected to MISO on the shield, the latter of which defaults to
    //INPUT mode on boot which makes it High-Z, which, in turn, allows the
    //pull-up inside the Si4735 to work its magic.
    //For non-Shield, non SPI configurations, leave GPO1 floating or tie to
    //HIGH.

    //Sequence the power to the Si4735



    //Use the longest of delays given in the datasheet
    _delay_ms(300);

    //Datasheet calls for no rising SCLK edge 300ns before RESET rising edge,
    //but Arduino can only go as low as ~1us.

	SI4735_PIN_RESET_HIGH;
    //Datasheet calls for 30ns delay; an Arduino running at 20MHz (4MHz
    //faster than the Uno. mind you) has a clock period of 50ns so no action
    //needed.

    //If we get to here and in SPI mode, we know GPO2 is not unused because
    //we just used it to select SPI mode. If we are in I2C mode, then we look
    //to see if the user wants interrupts and only then enable it.


//    Si4735_setMode(mode, 0);
}





void Si4735_setFrequency(uint16_t frequency){
    switch(_mode){
        case SI4735_MODE_FM:
            Si4735_sendCommand(SI4735_CMD_FM_TUNE_FREQ, 0x00, highByte(frequency),
                        lowByte(frequency),0,0,0,0);
            break;
        case SI4735_MODE_AM:
        case SI4735_MODE_SW:
        case SI4735_MODE_LW:
			if (_mode == SI4735_MODE_SW)
			{
				Si4735_sendCommand(SI4735_CMD_AM_TUNE_FREQ, 0x00, highByte(frequency),
				lowByte(frequency), 0x00,0x01,0,0);
			}
			else
			{
				Si4735_sendCommand(SI4735_CMD_AM_TUNE_FREQ, 0x00, highByte(frequency),
				lowByte(frequency), 0x00,0x00,0,0);
			}

            break;
    }
    Si4735_completeTune();

}

uint8_t Si4735_getRevision(char* FW, char* CMP, char *REV, uint8_t *patch){
    Si4735_sendCommand(SI4735_CMD_GET_REV,0,0,0,0,0,0,0);
    Si4735_getResponse();


        FW[0] = _response[2];
        FW[1] = _response[3];
        FW[2] = '\0';

        CMP[0] = _response[6];
        CMP[1] = _response[7];
        CMP[2] = '\0';

    REV[0] = _response[8];
    REV[1] = '\0';
	
    patch[0] = _response[4];
    patch[1] = _response[5];

    return _response[1];
}

uint16_t Si4735_getFrequency(){
    uint16_t frequency;

    switch(_mode){
        case SI4735_MODE_FM:
            Si4735_sendCommand(SI4735_CMD_FM_TUNE_STATUS,0,0,0,0,0,0,0);
            break;
        case SI4735_MODE_AM:
        case SI4735_MODE_SW:
        case SI4735_MODE_LW:
            Si4735_sendCommand(SI4735_CMD_AM_TUNE_STATUS,0,0,0,0,0,0,0);
            break;
    }
    Si4735_getResponse();
    frequency = word(_response[2], _response[3]);

    return frequency;
}

void Si4735_seekUp(uint8_t wrap){
    switch(_mode){
        case SI4735_MODE_FM:
//             Si4735_sendCommand(SI4735_CMD_FM_SEEK_START,
//                         (SI4735_FLG_SEEKUP |
//                          (if(wrap==1) ? SI4735_FLG_WRAP : 0x00)));
            break;
        case SI4735_MODE_AM:
        case SI4735_MODE_SW:
        case SI4735_MODE_LW:
//              Si4735_sendCommand(SI4735_CMD_AM_SEEK_START,
//                          (SI4735_FLG_SEEKUP | (if(wrap==1) ? SI4735_FLG_WRAP : 0x00)),
//                          0x00, 0x00, 0x00,
//                          ((_mode == SI4735_MODE_SW) ? 0x01 : 0x00),0,0);
            break;
    }
    Si4735_completeTune();
}

void Si4735_seekDown(uint8_t wrap){
    switch(_mode){
        case SI4735_MODE_FM:
//             Si4735_sendCommand(SI4735_CMD_FM_SEEK_START,
//                         (if(wrap==1) ? SI4735_FLG_WRAP : 0x00));
            break;
        case SI4735_MODE_AM:
        case SI4735_MODE_SW:
        case SI4735_MODE_LW:
//             Si4735_sendCommand(SI4735_CMD_AM_SEEK_START,
//                         (if(wrap==1) ? SI4735_FLG_WRAP : 0x00), 0x00, 0x00, 0x00,
//                         ((_mode == SI4735_MODE_SW) ? 0x01 : 0x00));
            break;
    }
    Si4735_completeTune();
}

void Si4735_setSeekThresholds(uint8_t SNR, uint8_t RSSI){
    switch(_mode){
        case SI4735_MODE_FM:
             Si4735_setProperty(SI4735_PROP_FM_SEEK_TUNE_SNR_THRESHOLD,
                         word(0x00, constrain(SNR, 0, 127)));
             Si4735_setProperty(SI4735_PROP_FM_SEEK_TUNE_RSSI_THRESHOLD,
                         word(0x00, constrain(RSSI, 0, 127)));
            break;
        case SI4735_MODE_AM:
        case SI4735_MODE_SW:
        case SI4735_MODE_LW:
             Si4735_setProperty(SI4735_PROP_AM_SEEK_TUNE_SNR_THRESHOLD,
                         word(0x00, constrain(SNR, 0, 63)));
             Si4735_setProperty(SI4735_PROP_AM_SEEK_TUNE_RSSI_THRESHOLD,
                         word(0x00, constrain(RSSI, 0, 63)));
            break;
    }
}



uint8_t Si4735_readRDSGroup(uint16_t * block){
    //See if there's anything for us to do
     if(((Si4735_getStatus() != SI4735_STATUS_RDSINT)))
         return 0;

    //Grab the next available RDS group from the chip
    Si4735_sendCommand(SI4735_CMD_FM_RDS_STATUS, SI4735_FLG_INTACK,0,0,0,0,0,0);
    Si4735_getResponse();
    //Of course, we got here because the chip just interrupted us to tell it has
    //received RDS data -- so much of it that the FIFO high-watermark was hit.
    //Still, it never hurts to be consistent so we'll set _haverds to the chip's
    //version of the facts (as opposed to a hardcoded true).
    _haverds = _response[1] & SI4735_FLG_RDSSYNCFOUND;
    //memcpy() would be faster but it won't help since we're of a different
    //endianness than the device we're talking to.
    block[0] = word(_response[4], _response[5]);
    block[1] = word(_response[6], _response[7]);
    block[2] = word(_response[8], _response[9]);
    block[3] = word(_response[10], _response[11]);

    return 1;
}

void Si4735_getRSQ(Si4735_RX_Metrics* RSQ){
    switch(_mode){
        case SI4735_MODE_FM:
            Si4735_sendCommand(SI4735_CMD_FM_RSQ_STATUS, SI4735_FLG_INTACK,0,0,0,0,0,0);
            break;
        case SI4735_MODE_AM:
        case SI4735_MODE_SW:
        case SI4735_MODE_LW:
            Si4735_sendCommand(SI4735_CMD_AM_RSQ_STATUS, SI4735_FLG_INTACK,0,0,0,0,0,0);
            break;
    }
    //Now read the response
    Si4735_getResponse();

    //Pull the response data into their respecive fields
    RSQ->RSSI = _response[4];
    RSQ->SNR = _response[5];
    if(_mode == SI4735_MODE_FM){
        RSQ->PILOT = _response[3] & SI4735_STATUS_PILOT;
        RSQ->STBLEND = (_response[3] & (~SI4735_STATUS_PILOT));
        RSQ->MULT = _response[6];
        RSQ->FREQOFF = _response[7];
    }
}



void Si4735_setDeemphasis(uint8_t deemph){
	switch(_mode){
		case SI4735_MODE_FM:
		Si4735_setProperty(SI4735_PROP_FM_DEEMPHASIS, word(0x00, deemph));
		break;
		case SI4735_MODE_AM:
		case SI4735_MODE_LW:
		case SI4735_MODE_SW:
		Si4735_setProperty(SI4735_PROP_AM_DEEMPHASIS, word(0x00, deemph));
		break;
	}
}




uint16_t Si4735_getProperty(uint16_t property){
    Si4735_sendCommand(SI4735_CMD_GET_PROPERTY, 0x00, highByte(property),
                lowByte(property),0,0,0,0);
    Si4735_getResponse();

    return word(_response[2], _response[3]);
}

